package com.example.lee.suesnews.common;

/**
 * 新闻种类
 * Created by Administrator on 2015/1/18.
 */
public class NewsTypes {

    //学校要闻
    public static final int NEWS_TPYE_XXYW = 1;
    //校园快讯
    public static final int NEWS_TPYE_XYKX = 2;
    //科教动态
    public static final int NEWS_TPYE_KJDT = 3;
    //媒体聚焦
    public static final int NEWS_TPYE_MTJJ = 4;
    //部门新闻
    public static final int NEWS_TPYE_BMXW = 5;
}
