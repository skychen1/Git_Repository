# GlideTransformationDemo

![GildeTransformation.gif](http://upload-images.jianshu.io/upload_images/2693519-df32ae7911185528.gif?imageMogr2/auto-orient/strip)
