# AnimLikeSougou
Android Animtaion 仿搜狗输入法的精品市场 一键安装dialog弹出效果，
具体可以看这篇blog: http://blog.csdn.net/lsmfeixiang/article/details/43019507

有图有真相
![image](https://github.com/teffy/AnimLikeSougou/blob/master/show.gif)
