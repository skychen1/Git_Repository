/** Automatically generated file. DO NOT MODIFY */
package com.example.listviewfilter.test;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}